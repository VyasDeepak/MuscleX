export { default } from './ExerciseDetailsScreen';
